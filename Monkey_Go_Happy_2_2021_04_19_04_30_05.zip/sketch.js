var PLAY = 1;
var END = 0;
var gameState = PLAY;
var score=0
var monkey,monkeyImg
var ground
var obstacleGroup
var foodGroup
 function preload(){
monkeyImg=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04g","Monkey_05png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png")
 }
function setup() {
  createCanvas(400, 400);
   monkey=createSprite(200,200,20,20);
  monkey.addAnimation("monkey",monkeyImg)
   ground=createSprite(200,388,400,10);
  obstacleGroup=createGroup();
     foodGroup=createGroup();
 
}

function draw() {
  background(220);
   text("Survival Time: "+ score, 250, 100);
  if(gameState===PLAY){
    
    monkey.velocityY=-12;
    ground.velocityX=-6;
        if(ground.x<0){
    ground.x = ground.width/2;
    }
  
    if(keyDown("space")){
      monkey.velocityY=-12;
    }
    monkey.velocityY=monkey.velocityY+0.8;
     spawnObstacles();
    spawnFood();
    ground.velocityX = -(2 + 2*score/800);
    //scoring
    score = score + Math.round(World.frameRate/60);
    if(keyDown("space") && monkey.y >= 359){
      monkey.velocityY = -12 ;
    }
  }
   if(obstacleGroup.isTouching(monkey)){
   gameState=END;
 }
else{
if(gameState===END){
  ground.velocityX = 0;
    monkey.velocityY =0;
    obstacleGroup.setVelocityXEach(0);
   foodGroup.setVelocityXEach(0);
       //set lifetime of the game objects so that they are never destroyed
    obstacleGroup.setLifetimeEach(-1);
    foodGroup.setLifetimeEach(-1);
}
}
  monkey.collide(ground); // THIS WAS ON LINE 35.
  //If should be followed immediately with else if
  
    drawSprites();
}
function spawnObstacles() {
  if(World.frameCount % 80 === 0) {
    var stone = createSprite(400,365,10,40);
    stone.velocityX = -6;
    stone.setCollider("circle",0,0,200);
    //generate random obstacles
 //   var rand = randomNumber(1,6);
   stone.setAnimation("Stone");
    
    //assign scale and lifetime to the obstacle           
    stone.scale = 0.2;
    stone.lifetime = 70;
    //add each obstacle to the group
    obstacleGroup.add(stone);
  }
}
function spawnFood() {
  //write code here to spawn the clouds
  if (World.frameCount % 110 === 0) {
    var food = createSprite(400,320,40,10);
    food.y = randomNumber(240,285);
     food.setAnimation("Banana");
    food.scale = 0.05;
     food.velocityX = -6;
    food.setCollider("circle",0,0,200)
     //assign lifetime to the variable
    food.lifetime = 134;
    
        //add each cloud to the group
    foodGroup.add(food);
  }
  
}